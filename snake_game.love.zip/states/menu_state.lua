local menu = {}

function menu:update(dt)
end

function menu:draw()
    love.graphics.print("Press Enter or Space to Start", 200, 200)
end

return menu
