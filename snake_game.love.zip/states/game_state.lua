local SnakeGame = require("snake_game")

local game_state = {}
local gameInstance = SnakeGame:new()

function game_state:update(dt)
    gameInstance:update(dt)
end

function game_state:draw()
    gameInstance:draw()
end

function game_state:changeDirection(dx, dy)
    gameInstance:changeDirection(dx, dy)
end

function game_state:reset()
    gameInstance:reset()
end

return game_state
